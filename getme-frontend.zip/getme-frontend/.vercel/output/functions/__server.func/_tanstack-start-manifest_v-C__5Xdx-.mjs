//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C__5Xdx-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-fCnJTvBU.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-fCnJTvBU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BvNegMH0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
