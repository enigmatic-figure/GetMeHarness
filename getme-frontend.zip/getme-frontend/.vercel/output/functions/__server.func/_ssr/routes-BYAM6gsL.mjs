import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Library, i as MessageSquare, n as ScrollText, o as Cpu, r as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, c as Slot, i as DialogOverlay, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BYAM6gsL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var variants = cva("inline-flex items-center justify-center gap-2 rounded-full px-4 text-sm font-medium min-h-11 transition-[background-color,color,scale,opacity] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", {
	variants: { variant: {
		primary: "bg-primary text-primary-ink",
		quiet: "border border-line bg-surface text-fg hover:bg-surface-2",
		ghost: "bg-transparent text-muted hover:bg-surface hover:text-fg",
		brass: "border border-accent bg-transparent text-fg hover:bg-surface"
	} },
	defaultVariants: { variant: "primary" }
});
function Button({ className, variant, asChild, type = "button", ...props }) {
	if (asChild) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
		className: cn(variants({ variant }), className),
		...props
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(variants({ variant }), className),
		...props
	});
}
var ACCESS = [
	{
		id: "start",
		label: "Start menu",
		detail: "A shortcut, named the way you ask."
	},
	{
		id: "desktop",
		label: "Desktop icon",
		detail: "One icon. Nothing pinned unless you say so."
	},
	{
		id: "taskbar",
		label: "Taskbar",
		detail: "Pinned after the first launch that succeeds."
	},
	{
		id: "bar",
		label: "This bar",
		detail: "Type the alias here. System PATH stays as it was."
	},
	{
		id: "hotkey",
		label: "A hotkey",
		detail: "You choose the keys. They are part of the receipt."
	}
];
var PERSISTENCE = [
	{
		id: "ask",
		label: "Ask me",
		detail: "If a task or setting you turned off comes back, stop and show it. Do not flip it until you decide."
	},
	{
		id: "notify",
		label: "Just tell me",
		detail: "Write it down and leave the machine as the other actor left it."
	},
	{
		id: "correct",
		label: "Put it back",
		detail: "Restore the off state you chose, and record that correction. Say so when it fights an update."
	}
];
var MACHINE = {
	os: "Windows 11 24H2",
	build: "26100",
	arch: "x64",
	cpu: "8 cores",
	ram: "32 GB",
	diskFree: "180 GB free on the system drive",
	wsl: "Installed",
	scoop: "Installed",
	gpu: "Not collected",
	gpuNote: "Read only if you pick something that needs a GPU.",
	executionPolicy: "RemoteSigned, current user only"
};
var MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function formatWhen(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	const h = d.getUTCHours();
	const hr = h % 12 || 12;
	const min = String(d.getUTCMinutes()).padStart(2, "0");
	const ampm = h >= 12 ? "PM" : "AM";
	return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${hr}:${min} ${ampm} UTC`;
}
function formatDay(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
}
function act(op, summary, args = {}) {
	return {
		op,
		summary,
		args
	};
}
var SOFTWARE = [
	{
		id: "comfyui",
		name: "ComfyUI",
		alias: "comfy",
		aliases: [
			"comfyui",
			"comfy-ui",
			"comfy ui"
		],
		blurb: "A node canvas for running image models on your machine.",
		publisher: "Comfy Org",
		keywords: [
			"image",
			"nodes",
			"diffusion",
			"canvas"
		],
		methods: [
			{
				id: "portable",
				label: "A Windows folder you can move",
				where: "Under your user profile, in GetMe’s folder. PATH is not changed.",
				opens: "Its own window.",
				tradeoff: "The larger download. Uses the GPU driver already on Windows. Closest to “it just opens.”",
				size: "About 2 GB before any model",
				recipe: "verified",
				recipeId: "comfyui-portable@2026.10.2",
				version: "2026.10.2",
				verify: "A window titled ComfyUI accepts a blank graph.",
				recovers: "Delete the owned folder. Nothing else was introduced.",
				actions: [
					act("precondition", "Confirm Windows 11 x64 and 8 GB free", {
						os: "26100",
						arch: "x64"
					}),
					act("fetch", "Download the pinned portable archive", { sha256: "c1a7e0…4b91" }),
					act("extract", "Extract into this installation’s folder", { to: "%LOCALAPPDATA%\\GetMe\\comfyui" }),
					act("own", "Mark that folder as owned by this install"),
					act("verify", "Launch and wait for the canvas")
				]
			},
			{
				id: "wsl",
				label: "Inside WSL, the way upstream docs assume",
				where: "A Linux environment already on this PC.",
				opens: "A browser tab aimed at the WSL service.",
				tradeoff: "Matches the project’s own instructions. GPU access depends on WSL, and it feels less like a Windows app.",
				size: "Depends on the image already present",
				recipe: "missing",
				recipeId: "none",
				version: "unpinned",
				verify: "The service answers on its local port.",
				recovers: "Stop the service and delete the venv recorded for this install.",
				actions: [
					act("precondition", "Confirm WSL is installed", { wsl: "present" }),
					act("discover", "No verified recipe — agent proposes a bounded plan"),
					act("venv", "Create a virtualenv inside the distro", { path: "~/GetMe/comfyui" }),
					act("fetch", "Install the pinned commit inside that venv"),
					act("verify", "Request the canvas and record the response")
				]
			},
			{
				id: "scoop",
				label: "Scoop, from PowerShell",
				where: "Scoop’s apps directory.",
				opens: "A Start menu shortcut, if you ask, plus the Scoop command.",
				tradeoff: "Updates the way Scoop updates. This pin is one release behind the portable package.",
				size: "Similar to the portable build",
				recipe: "lagging",
				recipeId: "comfyui-scoop@2026.09.1",
				version: "2026.09.1",
				verify: "The Scoop shim launches the canvas.",
				recovers: "scoop uninstall, then reconcile any shortcut GetMe added.",
				actions: [
					act("precondition", "Confirm Scoop is on this profile"),
					act("install", "Install the pinned Scoop manifest", { manifest: "comfyui" }),
					act("own", "Record the shim and the app directory"),
					act("verify", "Launch through the shim")
				]
			}
		]
	},
	{
		id: "voice-access",
		name: "Windows Voice Access",
		alias: "voice",
		aliases: [
			"voice access",
			"dictation",
			"windows dictation"
		],
		blurb: "The dictation already in Windows. GetMe turns it on and shows you the switch.",
		publisher: "Microsoft",
		keywords: [
			"dictation",
			"speech",
			"voice",
			"speak"
		],
		methods: [{
			id: "enable",
			label: "Turn on the Windows feature",
			where: "A setting for your user. No new program folder.",
			opens: "Voice Access from the Start menu.",
			tradeoff: "Nothing extra to download. It is Microsoft’s tool, with Microsoft’s language and account limits.",
			size: "Already on the machine",
			recipe: "verified",
			recipeId: "voice-access-hkcu@2026.10.1",
			version: "inbox",
			verify: "Voice Access reports ready for this user.",
			recovers: "Turn the same setting back off. No files to delete.",
			actions: [
				act("precondition", "Confirm the inbox component is present"),
				act("setting", "Enable Voice Access for this user", { scope: "HKCU" }),
				act("verify", "Read the setting back and confirm it stuck")
			]
		}]
	},
	{
		id: "whisper",
		name: "Whisper.cpp",
		alias: "whisper",
		aliases: [
			"whisper.cpp",
			"whisper cpp",
			"local whisper"
		],
		blurb: "Speech-to-text that stays on this PC.",
		publisher: "ggerganov and contributors",
		keywords: [
			"whisper",
			"transcribe",
			"offline",
			"speech"
		],
		methods: [{
			id: "portable",
			label: "A small local program and one model",
			where: "GetMe’s folder, with the model file beside it.",
			opens: "Drop a recording on it, or a hotkey if you ask for one.",
			tradeoff: "Private and offline. It does not type into every window unless you add that hotkey.",
			size: "About 180 MB with the small model",
			recipe: "verified",
			recipeId: "whisper-small@2026.10.4",
			version: "2026.10.4",
			verify: "A known sample clip returns a known sentence.",
			recovers: "Delete the owned folder, including the model, unless you keep the model.",
			actions: [
				act("fetch", "Download the pinned binary and the small model", { sha256: "91ab22…0ce4" }),
				act("extract", "Place them in the owned folder", { to: "%LOCALAPPDATA%\\GetMe\\whisper" }),
				act("verify", "Transcribe the fixture clip")
			]
		}]
	},
	{
		id: "geogebra",
		name: "GeoGebra",
		alias: "geo",
		aliases: ["geogebra", "geo gebra"],
		blurb: "Graphs, geometry, and calculus you can drag.",
		publisher: "GeoGebra",
		keywords: [
			"calculus",
			"graph",
			"geometry",
			"math"
		],
		methods: [{
			id: "classic",
			label: "GeoGebra Classic for Windows",
			where: "Its own folder under Program Files, recorded as owned.",
			opens: "A desktop window from the Start menu.",
			tradeoff: "Good for working problems. It will not quiz you. Pair it with cards if you want memory practice.",
			size: "About 120 MB",
			recipe: "verified",
			recipeId: "geogebra-classic@2026.08.2",
			version: "2026.08.2",
			verify: "The algebra view opens.",
			recovers: "Run the vendor uninstaller, then remove leftovers the receipt still owns.",
			actions: [
				act("fetch", "Download the pinned Classic installer", { sha256: "77c1…aa02" }),
				act("install", "Run it observed, writing only into the declared folder"),
				act("verify", "Open the algebra view")
			]
		}]
	},
	{
		id: "anki",
		name: "Anki",
		alias: "anki",
		aliases: ["anky"],
		blurb: "Flashcards with a review schedule. Useful beside GeoGebra, not a substitute for it.",
		publisher: "Ankitects",
		keywords: [
			"flashcard",
			"memory",
			"study",
			"calculus"
		],
		methods: [{
			id: "classic",
			label: "Anki for Windows",
			where: "Program Files, plus a collection folder in your profile if you create one.",
			opens: "Its own window.",
			tradeoff: "Your decks stay yours. GetMe does not create a deck unless you ask.",
			size: "About 80 MB",
			recipe: "verified",
			recipeId: "anki-win@2026.07.3",
			version: "2026.07.3",
			verify: "The deck list window opens.",
			recovers: "Vendor uninstall, then keep or delete the collection based on your choice.",
			actions: [
				act("fetch", "Download the pinned installer", { sha256: "ab90…11d2" }),
				act("install", "Run it observed"),
				act("verify", "Open the deck list")
			]
		}]
	},
	{
		id: "gnucash",
		name: "GnuCash",
		alias: "books",
		aliases: ["gnucash", "gnu cash"],
		blurb: "Double-entry books. A step away from QuickBooks, not a copy of it.",
		publisher: "The GnuCash project",
		keywords: [
			"quickbooks",
			"accounting",
			"ledger",
			"invoice",
			"bookkeeping"
		],
		methods: [{
			id: "classic",
			label: "GnuCash for Windows",
			where: "Program Files. A file association only for its own books.",
			opens: "The Start menu. Your company file stays wherever you save it.",
			tradeoff: "Does not open QuickBooks company files. The first launch can create a book, and only if you ask.",
			size: "About 150 MB",
			recipe: "verified",
			recipeId: "gnucash-win@2026.06.1",
			version: "2026.06.1",
			verify: "The empty-book window opens.",
			recovers: "Vendor uninstall. Book files you saved are kept unless you say otherwise.",
			actions: [
				act("fetch", "Download the pinned installer", { sha256: "d4e1…90ab" }),
				act("install", "Run it observed. Associate .gnucash only"),
				act("verify", "Open the tip-of-day window and close it")
			]
		}]
	},
	{
		id: "krita",
		name: "Krita",
		alias: "krita",
		aliases: ["krita"],
		blurb: "A drawing and painting program.",
		publisher: "Krita Foundation",
		keywords: [
			"paint",
			"draw",
			"illustration",
			"sketch"
		],
		methods: [{
			id: "classic",
			label: "Krita for Windows",
			where: "Program Files, owned in the receipt.",
			opens: "Its own window.",
			tradeoff: "Built for painting, not for photo libraries.",
			size: "About 300 MB",
			recipe: "verified",
			recipeId: "krita-win@5.2.9",
			version: "5.2.9",
			verify: "A blank canvas opens.",
			recovers: "Vendor uninstall, then reconcile owned leftovers. Pictures you exported stay.",
			actions: [
				act("fetch", "Download the pinned installer", { sha256: "e31c…77a0" }),
				act("install", "Run it observed"),
				act("verify", "Open a blank canvas")
			]
		}]
	},
	{
		id: "blender",
		name: "Blender",
		alias: "blend",
		aliases: ["blender"],
		blurb: "3D modeling, layout, and rendering.",
		publisher: "Blender Foundation",
		keywords: [
			"blender",
			"3d",
			"sculpt",
			"render"
		],
		methods: [{
			id: "portable",
			label: "A portable build in your profile",
			where: "GetMe’s folder. No system-wide association for .blend unless you ask later.",
			opens: "Its own window.",
			tradeoff: "Easy to remove cleanly. It will not take over every 3D file on the PC.",
			size: "About 320 MB",
			recipe: "verified",
			recipeId: "blender-portable@4.5.1",
			version: "4.5.1",
			verify: "The default scene appears.",
			recovers: "Delete the owned folder and the shortcuts you asked for.",
			actions: [
				act("fetch", "Download the pinned portable zip", { sha256: "b88d…12cf" }),
				act("extract", "Extract into the owned folder", { to: "%LOCALAPPDATA%\\GetMe\\blender" }),
				act("verify", "Open the default scene")
			]
		}]
	},
	{
		id: "beacon",
		name: "Beacon",
		alias: "beacon",
		aliases: [
			"beacon",
			"proof",
			"fixture"
		],
		blurb: "A small stand-in installer. It exists so removal can be shown, not promised.",
		publisher: "GetMe fixture",
		keywords: [
			"beacon",
			"fixture",
			"proof"
		],
		methods: [{
			id: "fixture",
			label: "The proof fixture",
			where: "A folder, one registry value of its own, one shared value, and a scheduled task.",
			opens: "A tiny window that says it is running.",
			tradeoff: "Not useful software. It is how you watch GetMe attribute a change, notice a conflict, and undo only what it owns.",
			size: "Under 2 MB",
			recipe: "verified",
			recipeId: "beacon-fixture@0.1.0",
			version: "0.1.0",
			verify: "The fixture window reports ready, and the task is registered.",
			recovers: "Delete owned files and the task. Shared values follow the conflict rules.",
			actions: [
				act("stage", "Create the fixture files in the owned folder"),
				act("registry", "Write the installer’s own key"),
				act("registry", "Set the shared Accent value, journaling the previous one"),
				act("task", "Register BeaconKeepAlive"),
				act("verify", "Confirm file, key, and task")
			]
		}]
	}
];
function softwareById(id) {
	return SOFTWARE.find((s) => s.id === id);
}
function methodOf(software, methodId) {
	return software.methods.find((m) => m.id === methodId);
}
function recipeLabel(state) {
	if (state === "verified") return "Verified recipe";
	if (state === "lagging") return "Verified, one release behind";
	return "No recipe yet";
}
var GOALS = [
	{
		re: /dictat|transcri|speech|when i speak|voice to text|talk to type/,
		ids: ["voice-access", "whisper"],
		via: "Dictation on this PC. These two are not the same kind of tool."
	},
	{
		re: /calculus|algebra|geometry|trigonometry|flash\s?cards?/,
		ids: ["geogebra", "anki"],
		via: "Two different jobs inside studying math."
	},
	{
		re: /quick\s?books?|book\s?keep|invoic|double[- ]entry|\bledger\b|\baccounting\b/,
		ids: ["gnucash"],
		via: "Bookkeeping. Not a QuickBooks importer."
	},
	{
		re: /comfy|stable diffusion|image model|node canvas/,
		ids: ["comfyui"],
		via: "A local canvas for image models."
	},
	{
		re: /\bpaint\b|illustrat|sketchbook|\bdraw\b|\bsketch\b/,
		ids: ["krita"],
		via: "Drawing and painting."
	},
	{
		re: /\bblender\b|\b3d\b|\bsculpt/,
		ids: ["blender"],
		via: "3D work."
	},
	{
		re: /\bbeacon\b|proof fixture|uninstall proof/,
		ids: ["beacon"],
		via: "The fixture that makes removal visible."
	}
];
function norm(s) {
	return s.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}
function compact(s) {
	return norm(s).replace(/ /g, "");
}
function levenshtein(a, b) {
	const m = a.length;
	const n = b.length;
	const dp = new Array(n + 1);
	for (let j = 0; j <= n; j++) dp[j] = j;
	for (let i = 1; i <= m; i++) {
		let prev = i - 1;
		dp[0] = i;
		for (let j = 1; j <= n; j++) {
			const tmp = dp[j] ?? 0;
			const cost = a[i - 1] === b[j - 1] ? 0 : 1;
			dp[j] = Math.min((dp[j] ?? 0) + 1, (dp[j - 1] ?? 0) + 1, prev + cost);
			prev = tmp;
		}
	}
	return dp[n] ?? 0;
}
function nameScore(query, software) {
	const q = compact(query);
	if (!q) return 0;
	const forms = [
		software.name,
		software.alias,
		...software.aliases
	].map(compact);
	let best = 0;
	for (const form of forms) {
		if (!form) continue;
		if (q === form) return 100;
		if (form.includes(q) || q.includes(form)) best = Math.max(best, 88);
		const limit = form.length <= 5 ? 1 : 2;
		const d = levenshtein(q, form);
		if (d <= limit) best = Math.max(best, 82 - d * 4);
	}
	return best;
}
function resolveQuery(query) {
	const scored = SOFTWARE.map((software) => ({
		software,
		score: nameScore(query, software)
	})).sort((a, b) => b.score - a.score);
	const top = scored[0];
	if (top && top.score >= 78) {
		const close = scored.filter((s) => s.score >= top.score - 8 && s.score >= 78).map((s) => s.software);
		if (close.length === 1) {
			const via = top.score === 100 ? "Known name." : `Interpreted “${query.trim()}” as ${top.software.name}.`;
			return {
				kind: "one",
				query,
				software: close[0],
				via
			};
		}
		return {
			kind: "many",
			query,
			software: close,
			via: "More than one name is close."
		};
	}
	for (const goal of GOALS) if (goal.re.test(query.toLowerCase())) {
		const software = goal.ids.map(softwareById).filter((s) => Boolean(s));
		if (software.length === 1) return {
			kind: "one",
			query,
			software: software[0],
			via: goal.via
		};
		if (software.length > 1) return {
			kind: "many",
			query,
			software,
			via: goal.via
		};
	}
	return {
		kind: "none",
		query
	};
}
function parseCommand(raw) {
	const text = raw.trim();
	if (!text) return { kind: "empty" };
	const lower = text.toLowerCase().replace(/\s+/g, " ");
	let match = lower.match(/^getgone\s+(.+)$/);
	if (match?.[1]) return {
		kind: "gone",
		alias: match[1]
	};
	match = lower.match(/^gethelp\s+(.+)$/);
	if (match?.[1]) return {
		kind: "help",
		alias: match[1]
	};
	if (lower === "getupdates" || lower === "get updates") return {
		kind: "updates",
		aliases: []
	};
	match = lower.match(/^get updates\s+(.+)$/);
	if (match?.[1]) return {
		kind: "updates",
		aliases: match[1].split(/[\s,]+/).filter(Boolean)
	};
	match = lower.match(/^getme\s+(.+)$/);
	if (match) return {
		kind: "getme",
		query: text.replace(/^getme\s+/i, "").trim()
	};
	return {
		kind: "getme",
		query: text
	};
}
function findInstall(alias, installs) {
	const q = compact(alias);
	const live = installs.filter((i) => i.status === "installed");
	const exact = live.find((i) => compact(i.alias) === q || compact(i.softwareId) === q);
	if (exact) return exact;
	let best;
	let bestD = 99;
	for (const install of live) {
		const d = Math.min(levenshtein(q, compact(install.alias)), levenshtein(q, compact(install.softwareId)));
		if (d < bestD) {
			bestD = d;
			best = install;
		}
	}
	if (best && bestD <= 1) return best;
}
function uniqueAlias(wanted, installs) {
	const taken = new Set(installs.filter((i) => i.status === "installed").map((i) => i.alias.toLowerCase()));
	const base = wanted.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-|-$/g, "") || "app";
	if (!taken.has(base)) return base;
	let n = 2;
	while (taken.has(`${base}-${n}`)) n += 1;
	return `${base}-${n}`;
}
function fnv1a(input) {
	let h = 2166136261;
	for (let i = 0; i < input.length; i++) {
		h ^= input.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return (h >>> 0).toString(16).padStart(8, "0");
}
function seal(events, prev = "getme-genesis") {
	const sealed = [];
	let cursor = prev;
	for (const event of events) {
		const hash = fnv1a(`${cursor}|${event.id}|${event.at}|${event.summary}`);
		sealed.push({
			...event,
			prev: cursor,
			hash
		});
		cursor = hash;
	}
	return {
		events: sealed,
		chainTip: cursor
	};
}
function planDocument(software, method) {
	return {
		schema: "getme.plan/v0",
		recipe: method.recipeId,
		recipeState: method.recipe,
		target: software.id,
		method: method.id,
		version: method.version,
		actions: method.actions,
		verify: method.verify,
		recovery: method.recovers,
		authority: "The executor checks this before any change. A model does not receive a shell."
	};
}
function rehearseScript(software, method) {
	if (method.recipe === "missing") return [
		`No verified recipe for ${software.name} via “${method.label}” on Windows 11 24H2.`,
		"Discovery stays bounded: one plan, one rehearsal, then you.",
		"The proposal passed the plan schema. That does not make it allowed to run.",
		"Rehearsal environment: modeled Windows. This profile is not changed.",
		...method.actions.map((a) => `Modeled: ${a.summary}.`),
		"Coverage gap: WSL GPU passthrough is not fully modeled. A real run would check it again.",
		"Rehearsal finished. This is a prediction, not an install."
	];
	const lag = method.recipe === "lagging" ? ["This recipe is verified for an older pin, one release behind."] : [];
	return [
		`Recipe ${method.recipeId} matches this profile.`,
		...lag,
		"Rehearsal environment: modeled Windows. Host files stay untouched.",
		...method.actions.map((a) => `Modeled: ${a.summary}.`),
		"No service. No scheduled task, unless the plan names one.",
		`Verification in the model: ${method.verify}`,
		"Rehearsal finished. The real run is still observed on its own."
	];
}
function installScript(software, method) {
	return [
		"Preconditions still hold on the sample profile.",
		...method.actions.map((a) => `Running: ${a.summary}.`),
		"Journaling effects as they happen. The agent receives a short status, not this stream.",
		`Check: ${method.verify}`,
		"Owned resources recorded. Shared runtimes introduced: none in this plan."
	];
}
function installDrafts(install, software, method, at) {
	const base = {
		at,
		installId: install.id,
		alias: install.alias
	};
	return [
		{
			...base,
			id: `${install.id}-recipe`,
			kind: "note",
			certainty: method.recipe === "missing" ? "partial" : "observed",
			summary: method.recipe === "missing" ? "Installed from a rehearsed discovery plan" : `Installed from ${method.recipeId}`,
			detail: `${software.name} via ${method.label}. Version pin ${method.version}.`
		},
		{
			...base,
			id: `${install.id}-place`,
			kind: software.id === "voice-access" ? "setting" : "file",
			certainty: "observed",
			summary: software.id === "voice-access" ? "Voice Access enabled for this user" : `Placed ${software.name}`,
			detail: method.where,
			after: method.version
		},
		{
			...base,
			id: `${install.id}-verify`,
			kind: "verify",
			certainty: "observed",
			summary: "Verification passed",
			detail: method.verify
		}
	];
}
function accessDraft(install, at, previous) {
	const labels = install.access.map((id) => ACCESS.find((a) => a.id === id)?.label ?? id);
	const hot = install.access.includes("hotkey") && install.hotkey ? ` Hotkey ${install.hotkey}.` : "";
	return {
		id: `${install.id}-access-${at}`,
		at,
		installId: install.id,
		alias: install.alias,
		kind: "access",
		certainty: "observed",
		summary: previous ? "Changed how it opens" : "Recorded how it opens",
		detail: `${labels.join(", ") || "No launcher added"}.${hot}`,
		before: previous,
		after: install.alias
	};
}
function removalScript(software, accent, keepDocs) {
	if (software.id === "beacon") return [
		"No vendor uninstaller. Beacon is a GetMe fixture.",
		"Deleting owned files under the GetMe folder.",
		"Removing scheduled task BeaconKeepAlive, including the copy that turned itself back on.",
		"Removing the Start menu shortcut.",
		accent === "leave" ? "Accent stays coral. MailStamp wrote that after Beacon. The later edit is kept." : accent === "phosphor" ? "Accent set back to phosphor, Beacon’s own value. Coral is overwritten because you asked." : "Accent set back to slate, the value from before Beacon. Both later edits are overwritten because you asked.",
		keepDocs ? "Keeping Documents\\Beacon\\notes.txt. You wrote that after install." : "Deleting Documents\\Beacon\\notes.txt because you said to.",
		"One earlier registry create was only partly observed. The key is removed only if it is still Beacon’s.",
		"Verification: owned paths are gone. Unrelated files are unchanged."
	];
	return [
		software.methods.some((m) => m.id === "portable" || m.id === "enable") ? "No vendor uninstaller needed for this method." : "Running the vendor uninstaller and watching what it actually removes.",
		"Deleting resources this install still solely owns.",
		"Leaving shared components that something else still needs.",
		keepDocs ? "Keeping files you created or exported." : "Deleting saved files you marked for removal.",
		"Verification: owned paths are absent. Later edits by other programs were not rolled back."
	];
}
function removalDrafts(install, software, at, accent, keepDocs) {
	const base = {
		at,
		installId: install.id,
		alias: install.alias,
		kind: "removal",
		certainty: "observed"
	};
	if (software.id === "beacon") {
		const accentDetail = accent === "leave" ? "Left HKCU\\Software\\Shared\\Accent at coral. Current owner is MailStamp, which is not managed here." : accent === "phosphor" ? "Restored Accent to phosphor at your request." : "Restored Accent to slate, the pre-Beacon value, at your request.";
		return [
			{
				...base,
				id: `${install.id}-rm-files-${at}`,
				summary: "Removed Beacon’s files and shortcut",
				detail: "Owned folder and Start menu shortcut."
			},
			{
				...base,
				id: `${install.id}-rm-task-${at}`,
				summary: "Removed BeaconKeepAlive",
				detail: "The task Beacon re-enabled on Nov 2 is deleted."
			},
			{
				...base,
				id: `${install.id}-rm-accent-${at}`,
				kind: "registry",
				summary: accent === "leave" ? "Kept the later Accent change" : "Rewound Accent as you asked",
				detail: accentDetail,
				before: "coral",
				after: accent === "leave" ? "coral" : accent
			},
			{
				...base,
				id: `${install.id}-rm-docs-${at}`,
				kind: "file",
				summary: keepDocs ? "Kept your Beacon notes" : "Deleted your Beacon notes",
				detail: "Documents\\Beacon\\notes.txt"
			},
			{
				...base,
				id: `${install.id}-rm-verify-${at}`,
				kind: "verify",
				certainty: "partial",
				summary: "Removal checked against the receipt",
				detail: "Owned paths absent. The partial observation on Beacon’s own key is called out, not hidden."
			}
		];
	}
	return [
		{
			...base,
			id: `${install.id}-rm-${at}`,
			summary: `Removed ${software.name}`,
			detail: removalScript(software, accent, keepDocs).join(" ")
		},
		{
			...base,
			id: `${install.id}-rm-docs-${at}`,
			kind: "file",
			summary: keepDocs ? "Kept files you created" : "Deleted saved files you marked",
			detail: "User documents are not treated as leftovers."
		},
		{
			...base,
			id: `${install.id}-rm-verify-${at}`,
			kind: "verify",
			summary: "Removal checked",
			detail: "Owned resources gone. Later unrelated edits left in place."
		}
	];
}
function updateScript(software, from, to) {
	return [
		`Update pin ${from} → ${to} for ${software.name}.`,
		"The new pin is rehearsed against this profile’s preconditions.",
		"Replacing owned program files. Settings and documents stay.",
		"Verification rerun. The receipt gains this revision; it does not forget the old one."
	];
}
function buildSeed() {
	const installs = [
		{
			id: "ins-krita",
			softwareId: "krita",
			alias: "krita",
			methodId: "classic",
			version: "5.2.9",
			installedAt: "2026-09-12T18:10:00.000Z",
			access: ["start"],
			hotkey: "",
			status: "installed"
		},
		{
			id: "ins-blender",
			softwareId: "blender",
			alias: "blend",
			methodId: "portable",
			version: "4.5.1",
			installedAt: "2026-10-05T16:40:00.000Z",
			access: ["start", "bar"],
			hotkey: "",
			status: "installed",
			updateTo: "4.5.4"
		},
		{
			id: "ins-beacon",
			softwareId: "beacon",
			alias: "beacon",
			methodId: "fixture",
			version: "0.1.0",
			installedAt: "2026-10-18T15:05:00.000Z",
			access: ["start"],
			hotkey: "",
			status: "installed",
			attention: "Its scheduled task turned itself back on after you disabled it."
		}
	];
	const sealed = seal([
		{
			id: "e-profile",
			at: "2026-09-01T15:00:00.000Z",
			installId: "getme",
			alias: "getme",
			kind: "note",
			summary: "Collected a minimal machine profile",
			detail: "Windows 11 24H2, x64, 8 cores, 32 GB RAM. GPU was not read. Disk free space was read because installs need it.",
			certainty: "observed"
		},
		{
			id: "e-watch",
			at: "2026-09-01T15:02:00.000Z",
			installId: "getme",
			alias: "getme",
			kind: "note",
			summary: "Observation is on",
			detail: "Files, registry, services, and scheduled tasks. This watcher is itself revocable from This PC.",
			certainty: "observed"
		},
		{
			id: "e-krita-file",
			at: "2026-09-12T18:12:00.000Z",
			installId: "ins-krita",
			alias: "krita",
			kind: "file",
			summary: "Installed Krita from krita-win@5.2.9",
			detail: "Program Files folder recorded as owned. No extra file associations.",
			certainty: "observed"
		},
		{
			id: "e-krita-cut",
			at: "2026-09-12T18:13:00.000Z",
			installId: "ins-krita",
			alias: "krita",
			kind: "shortcut",
			summary: "Start menu shortcut added",
			detail: "Opens Krita. No desktop icon.",
			certainty: "observed"
		},
		{
			id: "e-krita-ok",
			at: "2026-09-12T18:14:00.000Z",
			installId: "ins-krita",
			alias: "krita",
			kind: "verify",
			summary: "A blank canvas opened",
			detail: "Verification passed.",
			certainty: "observed"
		},
		{
			id: "e-blend-file",
			at: "2026-10-05T16:42:00.000Z",
			installId: "ins-blender",
			alias: "blend",
			kind: "file",
			summary: "Installed Blender from blender-portable@4.5.1",
			detail: "Portable folder under %LOCALAPPDATA%\\GetMe\\blender. .blend files were not claimed.",
			certainty: "observed"
		},
		{
			id: "e-blend-open",
			at: "2026-10-05T16:44:00.000Z",
			installId: "ins-blender",
			alias: "blend",
			kind: "access",
			summary: "Opens from the Start menu and the alias blend",
			detail: "Typing blend in this bar launches it. PATH was not edited.",
			certainty: "observed"
		},
		{
			id: "e-blend-ok",
			at: "2026-10-05T16:45:00.000Z",
			installId: "ins-blender",
			alias: "blend",
			kind: "verify",
			summary: "Default scene appeared",
			detail: "Verification passed.",
			certainty: "observed"
		},
		{
			id: "e-blend-upd",
			at: "2026-11-01T12:00:00.000Z",
			installId: "ins-blender",
			alias: "blend",
			kind: "update",
			summary: "A newer pin is available: 4.5.4",
			detail: "Not installed. Your 4.5.1 receipt still stands.",
			certainty: "observed"
		},
		{
			id: "e-bea-file",
			at: "2026-10-18T15:06:00.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "file",
			summary: "Created Beacon’s program files",
			detail: "%LOCALAPPDATA%\\GetMe\\beacon\\beacon.exe and keep-alive.xml.",
			certainty: "observed"
		},
		{
			id: "e-bea-own",
			at: "2026-10-18T15:06:20.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "registry",
			summary: "Wrote Beacon’s own install key",
			detail: "HKCU\\Software\\GetMe\\Beacon\\Installed. The before-image was missed in a short gap; attribution used process ancestry.",
			before: "(absent)",
			after: "1",
			certainty: "partial"
		},
		{
			id: "e-bea-accent",
			at: "2026-10-18T15:06:30.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "registry",
			summary: "Changed shared Accent from slate to phosphor",
			detail: "HKCU\\Software\\Shared\\Accent. The previous value was stored before the write.",
			before: "slate",
			after: "phosphor",
			certainty: "observed"
		},
		{
			id: "e-bea-task",
			at: "2026-10-18T15:06:40.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "task",
			summary: "Registered scheduled task BeaconKeepAlive",
			detail: "\\GetMe\\BeaconKeepAlive. Solely owned by this install.",
			certainty: "observed"
		},
		{
			id: "e-bea-ok",
			at: "2026-10-18T15:07:00.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "verify",
			summary: "Fixture reported ready",
			detail: "File, key, and task matched the plan.",
			certainty: "observed"
		},
		{
			id: "e-bea-notes",
			at: "2026-10-19T20:12:00.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "file",
			summary: "You created notes beside Beacon",
			detail: "Documents\\Beacon\\notes.txt. This is yours, not payload. Removal keeps it unless you say otherwise.",
			certainty: "observed"
		},
		{
			id: "e-bea-off",
			at: "2026-10-20T13:30:00.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "task",
			summary: "You disabled BeaconKeepAlive",
			detail: "Recorded as a chosen off state.",
			before: "enabled",
			after: "disabled",
			certainty: "observed"
		},
		{
			id: "e-bea-mail",
			at: "2026-10-24T09:18:00.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "registry",
			summary: "MailStamp changed Accent from phosphor to coral",
			detail: "MailStamp is not a GetMe install. Beacon no longer owns the current value. Removal must not assume slate.",
			before: "phosphor",
			after: "coral",
			certainty: "observed"
		},
		{
			id: "e-bea-on",
			at: "2026-11-02T07:44:00.000Z",
			installId: "ins-beacon",
			alias: "beacon",
			kind: "task",
			summary: "BeaconKeepAlive turned itself back on",
			detail: "beacon.exe re-enabled the task you had disabled. Policy is “ask,” so it was not silently corrected.",
			before: "disabled",
			after: "enabled",
			certainty: "observed"
		}
	]);
	return {
		installs,
		events: sealed.events,
		chainTip: sealed.chainTip
	};
}
var SUGGESTIONS = [
	"comfyui",
	"something that takes dictation when I speak",
	"something that can help me study for calculus",
	"an alternative to quickbooks",
	"getgone beacon"
];
function Panel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-3xl border border-line bg-surface p-5", className),
		children
	});
}
function Pill({ children, tone = "quiet" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border px-2.5 py-1 text-sm", tone === "live" && "border-primary/40 bg-primary/10 text-primary", tone === "brass" && "border-accent/50 bg-accent/10 text-accent", tone === "quiet" && "border-line bg-bg text-muted"),
		children
	});
}
function RecipePill({ state }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: state === "missing" ? "brass" : "live",
		children: recipeLabel(state)
	});
}
function CertaintyPill({ certainty }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: certainty === "observed" ? "quiet" : "brass",
		children: certainty === "observed" ? "Observed" : certainty === "partial" ? "Partial" : "Gap"
	});
}
function Transcript({ lines }) {
	if (!lines.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-mono text-sm text-faint",
		children: "Waiting."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		"aria-live": "polite",
		className: "flex flex-col gap-2",
		children: lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "border-l border-primary pl-3 font-mono text-sm text-fg",
			children: line
		}, `${index}-${line.slice(0, 24)}`))
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1.5 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium text-fg",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-faint",
				children: hint
			}) : null
		]
	});
}
var inputClass = "min-h-11 w-full rounded-2xl border border-line bg-bg px-3 text-base text-fg outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";
function blankJourney(partial) {
	return {
		via: "",
		candidateIds: [],
		script: [],
		scriptIndex: 0,
		aliasDraft: "",
		accessDraft: ["start"],
		hotkeyDraft: "",
		share: false,
		...partial
	};
}
function nowStamp() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function append(state, drafts) {
	const sealed = seal(drafts, state.chainTip);
	return {
		events: [...state.events, ...sealed.events],
		chainTip: sealed.chainTip
	};
}
var seeded = buildSeed();
var initial = {
	installs: seeded.installs,
	events: seeded.events,
	chainTip: seeded.chainTip,
	policy: {
		persistence: "ask",
		shareMetadata: false
	},
	selfRemoved: false,
	view: "ask",
	journey: null,
	gone: null,
	help: null,
	helpError: null,
	notice: null,
	recordFilter: "all",
	updateFocus: [],
	updateRun: null
};
var useGetme = create()(persist((set, get) => ({
	...initial,
	setView: (view) => set({
		view,
		notice: null
	}),
	setNotice: (notice) => set({ notice }),
	setRecordFilter: (recordFilter) => set({
		recordFilter,
		view: "record"
	}),
	setPolicy: (patch) => set({ policy: {
		...get().policy,
		...patch
	} }),
	submit: (raw) => {
		const cmd = parseCommand(raw);
		const state = get();
		if (cmd.kind === "empty") return;
		if (cmd.kind === "gone") {
			const install = findInstall(cmd.alias, state.installs);
			if (!install) {
				set({
					notice: `Nothing managed here is called “${cmd.alias.trim()}”.`,
					view: "library",
					help: null,
					gone: null
				});
				return;
			}
			set({
				view: "library",
				notice: null,
				help: null,
				gone: {
					installId: install.id,
					phase: "review",
					accent: "leave",
					keepDocs: true,
					script: [],
					scriptIndex: 0
				}
			});
			return;
		}
		if (cmd.kind === "help") {
			const install = findInstall(cmd.alias, state.installs);
			if (!install) {
				set({
					notice: `Nothing managed here is called “${cmd.alias.trim()}”.`,
					view: "library"
				});
				return;
			}
			set({
				view: "library",
				notice: null,
				gone: null,
				helpError: null,
				help: {
					installId: install.id,
					alias: install.alias,
					access: [...install.access],
					hotkey: install.hotkey
				}
			});
			return;
		}
		if (cmd.kind === "updates") {
			set({
				view: "updates",
				notice: null,
				updateFocus: cmd.aliases,
				gone: null,
				help: null
			});
			return;
		}
		const resolved = resolveQuery(cmd.query);
		if (resolved.kind === "none") {
			set({
				view: "ask",
				notice: null,
				gone: null,
				help: null,
				journey: blankJourney({
					query: cmd.query,
					phase: "none"
				})
			});
			return;
		}
		if (resolved.kind === "many") {
			set({
				view: "ask",
				notice: null,
				gone: null,
				help: null,
				journey: blankJourney({
					query: cmd.query,
					phase: "pick",
					via: resolved.via,
					candidateIds: resolved.software.map((s) => s.id)
				})
			});
			return;
		}
		const existing = state.installs.find((i) => i.status === "installed" && i.softwareId === resolved.software.id);
		if (existing) {
			set({
				view: "ask",
				notice: null,
				gone: null,
				help: null,
				journey: blankJourney({
					query: cmd.query,
					phase: "present",
					via: resolved.via,
					softwareId: resolved.software.id,
					candidateIds: [resolved.software.id],
					installId: existing.id
				})
			});
			return;
		}
		set({
			view: "ask",
			notice: null,
			gone: null,
			help: null,
			journey: blankJourney({
				query: cmd.query,
				phase: "method",
				via: resolved.via,
				softwareId: resolved.software.id,
				candidateIds: [resolved.software.id]
			})
		});
	},
	pickSoftware: (id) => {
		const journey = get().journey;
		const software = softwareById(id);
		if (!journey || !software) return;
		const existing = get().installs.find((i) => i.status === "installed" && i.softwareId === id);
		if (existing) {
			set({ journey: {
				...journey,
				phase: "present",
				softwareId: id,
				installId: existing.id,
				via: journey.via
			} });
			return;
		}
		set({ journey: {
			...journey,
			phase: "method",
			softwareId: id
		} });
	},
	pickMethod: (methodId) => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			phase: "plan",
			methodId
		} });
	},
	showMethods: () => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			phase: "method",
			methodId: void 0,
			script: [],
			scriptIndex: 0
		} });
	},
	showCandidates: () => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			phase: "pick",
			softwareId: void 0,
			methodId: void 0
		} });
	},
	startRehearse: () => {
		const journey = get().journey;
		if (!journey?.softwareId || !journey.methodId) return;
		const software = softwareById(journey.softwareId);
		const method = software && methodOf(software, journey.methodId);
		if (!software || !method) return;
		set({ journey: {
			...journey,
			phase: "rehearse",
			script: rehearseScript(software, method),
			scriptIndex: 0
		} });
	},
	startInstall: () => {
		const journey = get().journey;
		if (!journey?.softwareId || !journey.methodId) return;
		const software = softwareById(journey.softwareId);
		const method = software && methodOf(software, journey.methodId);
		if (!software || !method) return;
		set({ journey: {
			...journey,
			phase: "install",
			script: installScript(software, method),
			scriptIndex: 0
		} });
	},
	advanceJourney: () => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			scriptIndex: Math.min(journey.script.length, journey.scriptIndex + 1)
		} });
	},
	skipJourney: () => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			scriptIndex: journey.script.length
		} });
	},
	commitInstall: () => {
		const state = get();
		const journey = state.journey;
		if (!journey?.softwareId || !journey.methodId) return;
		const software = softwareById(journey.softwareId);
		const method = software && methodOf(software, journey.methodId);
		if (!software || !method) return;
		const alias = uniqueAlias(software.alias, state.installs);
		const at = nowStamp();
		const install = {
			id: `ins-${software.id}-${at.slice(11, 19).replace(/:/g, "")}`,
			softwareId: software.id,
			alias,
			methodId: method.id,
			version: method.version,
			installedAt: at,
			access: ["start"],
			hotkey: "",
			status: "installed"
		};
		const next = append(state, [...installDrafts(install, software, method, at), accessDraft(install, at)]);
		set({
			installs: [...state.installs, install],
			...next,
			journey: {
				...journey,
				phase: "fit",
				installId: install.id,
				aliasDraft: alias,
				accessDraft: ["start"],
				hotkeyDraft: ""
			}
		});
	},
	setAliasDraft: (aliasDraft) => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			aliasDraft
		} });
	},
	toggleAccess: (key) => {
		const journey = get().journey;
		if (!journey) return;
		const accessDraft = journey.accessDraft.includes(key) ? journey.accessDraft.filter((k) => k !== key) : [...journey.accessDraft, key];
		set({ journey: {
			...journey,
			accessDraft
		} });
	},
	setHotkeyDraft: (hotkeyDraft) => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			hotkeyDraft
		} });
	},
	setShare: (share) => {
		const journey = get().journey;
		if (!journey) return;
		set({ journey: {
			...journey,
			share
		} });
	},
	saveFit: () => {
		const state = get();
		const journey = state.journey;
		if (!journey?.installId) return;
		const install = state.installs.find((i) => i.id === journey.installId);
		if (!install) return;
		const alias = uniqueAlias(journey.aliasDraft || install.alias, state.installs.filter((i) => i.id !== install.id));
		const access = journey.accessDraft.length ? journey.accessDraft : install.access;
		const hotkey = access.includes("hotkey") ? journey.hotkeyDraft.trim() : "";
		if (access.includes("hotkey") && !hotkey) {
			set({ notice: "Type the hotkey, or turn that option off." });
			return;
		}
		const nextInstall = {
			...install,
			alias,
			access,
			hotkey
		};
		const at = nowStamp();
		const previous = `${install.alias}: ${install.access.join(", ")}`;
		const next = alias !== install.alias || hotkey !== install.hotkey || access.join() !== install.access.join() ? append(state, [accessDraft(nextInstall, at, previous)]) : {
			events: state.events,
			chainTip: state.chainTip
		};
		set({
			installs: state.installs.map((i) => i.id === install.id ? nextInstall : i),
			...next,
			journey: {
				...journey,
				phase: "done",
				aliasDraft: alias
			}
		});
	},
	anotherCopy: () => {
		const journey = get().journey;
		if (!journey?.softwareId) return;
		set({ journey: {
			...journey,
			phase: "method",
			installId: void 0,
			methodId: void 0,
			via: "Another copy, with its own receipt."
		} });
	},
	openGone: (installId) => set({
		gone: {
			installId,
			phase: "review",
			accent: "leave",
			keepDocs: true,
			script: [],
			scriptIndex: 0
		},
		help: null
	}),
	closeGone: () => set({ gone: null }),
	setAccent: (accent) => {
		const gone = get().gone;
		if (!gone || gone.phase !== "review") return;
		set({ gone: {
			...gone,
			accent
		} });
	},
	setKeepDocs: (keepDocs) => {
		const gone = get().gone;
		if (!gone || gone.phase !== "review") return;
		set({ gone: {
			...gone,
			keepDocs
		} });
	},
	beginRemoval: () => {
		const gone = get().gone;
		if (!gone) return;
		const install = get().installs.find((i) => i.id === gone.installId);
		const software = install && softwareById(install.softwareId);
		if (!software) return;
		set({ gone: {
			...gone,
			phase: "working",
			script: removalScript(software, gone.accent, gone.keepDocs),
			scriptIndex: 0
		} });
	},
	advanceGone: () => {
		const gone = get().gone;
		if (!gone) return;
		set({ gone: {
			...gone,
			scriptIndex: Math.min(gone.script.length, gone.scriptIndex + 1)
		} });
	},
	skipGone: () => {
		const gone = get().gone;
		if (!gone) return;
		set({ gone: {
			...gone,
			scriptIndex: gone.script.length
		} });
	},
	completeGone: () => {
		const state = get();
		const gone = state.gone;
		if (!gone || gone.phase !== "working") return;
		const install = state.installs.find((i) => i.id === gone.installId);
		const software = install && softwareById(install.softwareId);
		if (!install || !software) return;
		const at = nowStamp();
		set({
			...append(state, removalDrafts(install, software, at, gone.accent, gone.keepDocs)),
			installs: state.installs.map((i) => i.id === install.id ? {
				...i,
				status: "removed",
				removedAt: at,
				attention: void 0,
				updateTo: void 0
			} : i),
			gone: {
				...gone,
				phase: "done"
			}
		});
	},
	openHelp: (installId) => {
		const install = get().installs.find((i) => i.id === installId && i.status === "installed");
		if (!install) return;
		set({
			help: {
				installId,
				alias: install.alias,
				access: [...install.access],
				hotkey: install.hotkey
			},
			helpError: null,
			gone: null
		});
	},
	closeHelp: () => set({
		help: null,
		helpError: null
	}),
	setHelpAlias: (alias) => {
		const help = get().help;
		if (!help) return;
		set({
			help: {
				...help,
				alias
			},
			helpError: null
		});
	},
	toggleHelpAccess: (key) => {
		const help = get().help;
		if (!help) return;
		const has = help.access.includes(key);
		set({ help: {
			...help,
			access: has ? help.access.filter((k) => k !== key) : [...help.access, key]
		} });
	},
	setHelpHotkey: (hotkey) => {
		const help = get().help;
		if (!help) return;
		set({ help: {
			...help,
			hotkey
		} });
	},
	saveHelp: () => {
		const state = get();
		const help = state.help;
		if (!help) return;
		const install = state.installs.find((i) => i.id === help.installId);
		if (!install) return;
		const alias = help.alias.trim().toLowerCase();
		if (!/^[a-z][a-z0-9-]{0,24}$/.test(alias)) {
			set({ helpError: "Use a short name: a letter, then letters, numbers, or hyphens." });
			return;
		}
		if (state.installs.some((i) => i.status === "installed" && i.id !== install.id && i.alias === alias)) {
			set({ helpError: "That name already belongs to another install." });
			return;
		}
		const access = help.access;
		const hotkey = access.includes("hotkey") ? help.hotkey.trim() : "";
		if (access.includes("hotkey") && !hotkey) {
			set({ helpError: "Type the hotkey, or turn that option off." });
			return;
		}
		const nextInstall = {
			...install,
			alias,
			access,
			hotkey
		};
		const changed = alias !== install.alias || hotkey !== install.hotkey || access.join() !== install.access.join();
		const previous = `${install.alias}: ${install.access.join(", ")}`;
		const next = changed ? append(state, [accessDraft(nextInstall, nowStamp(), previous)]) : {
			events: state.events,
			chainTip: state.chainTip
		};
		set({
			installs: state.installs.map((i) => i.id === install.id ? nextInstall : i),
			...next,
			help: null,
			helpError: null,
			notice: changed ? `${softwareById(install.softwareId)?.name ?? "It"} now answers to ${alias}.` : null
		});
	},
	startUpdate: (installId) => {
		const install = get().installs.find((i) => i.id === installId);
		const software = install && softwareById(install.softwareId);
		if (!install?.updateTo || !software) return;
		set({ updateRun: {
			installId,
			script: updateScript(software, install.version, install.updateTo),
			scriptIndex: 0
		} });
	},
	advanceUpdate: () => {
		const updateRun = get().updateRun;
		if (!updateRun) return;
		set({ updateRun: {
			...updateRun,
			scriptIndex: Math.min(updateRun.script.length, updateRun.scriptIndex + 1)
		} });
	},
	skipUpdate: () => {
		const updateRun = get().updateRun;
		if (!updateRun) return;
		set({ updateRun: {
			...updateRun,
			scriptIndex: updateRun.script.length
		} });
	},
	finishUpdate: () => {
		const state = get();
		const run = state.updateRun;
		if (!run) return;
		const install = state.installs.find((i) => i.id === run.installId);
		const software = install && softwareById(install.softwareId);
		if (!install?.updateTo || !software) return;
		const from = install.version;
		const to = install.updateTo;
		const at = nowStamp();
		set({
			...append(state, [{
				id: `${install.id}-upd-${at}`,
				at,
				installId: install.id,
				alias: install.alias,
				kind: "update",
				certainty: "observed",
				summary: `Updated ${software.name} from ${from} to ${to}`,
				detail: "Owned program files replaced. Settings and documents were not reset. The older pin stays in the record.",
				before: from,
				after: to
			}]),
			installs: state.installs.map((i) => i.id === install.id ? {
				...i,
				version: to,
				updateTo: void 0
			} : i),
			updateRun: null,
			notice: `${software.name} is on pin ${to}.`
		});
	},
	acknowledgeShare: () => {
		const state = get();
		const journey = state.journey;
		if (!journey?.installId || journey.share) return;
		const install = state.installs.find((i) => i.id === journey.installId);
		if (!install) return;
		const at = nowStamp();
		set({
			...append(state, [{
				id: `${install.id}-share-${at}`,
				at,
				installId: install.id,
				alias: install.alias,
				kind: "note",
				certainty: "observed",
				summary: "A redacted receipt was marked for sharing",
				detail: "Paths and account details stripped. Nothing was uploaded — this rehearsal has no share service connected."
			}]),
			journey: {
				...journey,
				share: true
			}
		});
	},
	depart: () => set({
		selfRemoved: true,
		journey: null,
		gone: null,
		help: null,
		updateRun: null
	}),
	reset: () => {
		const fresh = buildSeed();
		set({
			...initial,
			installs: fresh.installs,
			events: fresh.events,
			chainTip: fresh.chainTip,
			selfRemoved: false,
			policy: {
				persistence: "ask",
				shareMetadata: false
			}
		});
	}
}), {
	name: "getme-front-v1",
	skipHydration: true,
	storage: createJSONStorage(() => localStorage),
	partialize: (state) => ({
		installs: state.installs,
		events: state.events,
		chainTip: state.chainTip,
		policy: state.policy,
		selfRemoved: state.selfRemoved
	})
}));
function usePlayScript(playing, index, length, onStep, onSkip) {
	(0, import_react.useEffect)(() => {
		if (!playing || length === 0 || index >= length) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			onSkip();
			return;
		}
		const timer = window.setTimeout(onStep, 460);
		return () => window.clearTimeout(timer);
	}, [
		playing,
		index,
		length,
		onStep,
		onSkip
	]);
}
var STEPS = [
	"Choose",
	"Plan",
	"Rehearse",
	"Install",
	"Yours"
];
function stepIndex(phase) {
	if (phase === "pick" || phase === "method") return 0;
	if (phase === "plan") return 1;
	if (phase === "rehearse") return 2;
	if (phase === "install") return 3;
	return 4;
}
function Ask() {
	const journey = useGetme((s) => s.journey);
	const events = useGetme((s) => s.events);
	const installs = useGetme((s) => s.installs);
	const submit = useGetme((s) => s.submit);
	const advance = useGetme((s) => s.advanceJourney);
	const skip = useGetme((s) => s.skipJourney);
	const scriptDone = Boolean(journey && journey.script.length > 0 && journey.scriptIndex >= journey.script.length);
	const playing = (journey?.phase === "rehearse" || journey?.phase === "install") && !scriptDone;
	usePlayScript(Boolean(playing), journey?.scriptIndex ?? 0, journey?.script.length ?? 0, advance, skip);
	const harnessLabel = playing ? "Working" : journey?.phase === "rehearse" || journey?.phase === "install" ? "Ready" : journey?.phase === "fit" || journey?.phase === "done" ? "Recorded" : "Idle";
	const attention = installs.filter((i) => i.status === "installed" && (i.attention || i.updateTo));
	const recent = [...events].reverse().slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-start gap-3 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "flex flex-col gap-4",
			children: [journey && journey.phase !== "none" && journey.phase !== "present" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-wrap gap-2",
				children: STEPS.map((label, index) => {
					const current = stepIndex(journey.phase);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: index === current ? "rounded-full bg-primary px-3 py-1 text-sm font-medium text-primary-ink" : index < current ? "rounded-full border border-primary/40 px-3 py-1 text-sm text-primary" : "rounded-full border border-line px-3 py-1 text-sm text-faint",
						children: label
					}, label);
				})
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Decision, {})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Harness"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
						tone: playing ? "live" : "quiet",
						children: harnessLabel
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "The agent, when one is needed, gets a short status. This side is the local transcript. It is not fed back into a model."
				}),
				journey && (journey.phase === "rehearse" || journey.phase === "install" || journey.phase === "fit" || journey.phase === "done") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transcript, { lines: journey.script.slice(0, journey.scriptIndex) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [attention.map((install) => {
						const software = softwareById(install.softwareId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => install.attention ? submit(`getgone ${install.alias}`) : submit("getupdates"),
							className: "rounded-2xl border border-accent/50 bg-bg px-4 py-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium text-fg",
								children: software?.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm text-muted",
								children: install.attention ?? `Pin ${install.updateTo} is available. ${install.version} is what you have.`
							})]
						}, install.id);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium text-muted",
							children: "Latest in the record"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-2",
							children: recent.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "text-sm text-fg",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-faint",
										children: event.hash
									}),
									" ",
									event.summary
								]
							}, event.id))
						})]
					})]
				}),
				playing && journey && journey.scriptIndex < journey.script.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: skip,
					children: "Show the rest"
				}) : null
			]
		})]
	});
}
function Decision() {
	const journey = useGetme((s) => s.journey);
	const submit = useGetme((s) => s.submit);
	if (!journey) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Idle, { onPick: submit });
	if (journey.phase === "none") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(None, {
		query: journey.query,
		onPick: submit
	});
	if (journey.phase === "pick") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, { journey });
	if (journey.phase === "present") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Present, { journey });
	if (journey.phase === "method") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Methods, { journey });
	if (journey.phase === "plan") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plan, { journey });
	if (journey.phase === "rehearse") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rehearse, { journey });
	if (journey.phase === "install") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Installing, { journey });
	if (journey.phase === "fit") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fit, { journey });
	if (journey.phase === "done") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { journey });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Idle, { onPick: submit });
}
function Idle({ onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold",
					children: "Tell it what you need."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "A name, or the job. You get a choice in plain language, then a receipt you can reverse."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2",
				children: SUGGESTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onPick(item),
					className: "min-h-11 rounded-2xl border border-line px-4 text-left text-sm text-fg hover:border-primary/50 hover:bg-bg",
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "grid gap-2 text-sm text-muted sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Spelling is recovered. Two fits means two choices." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You see where it lives, and the trade-off that matters." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The receipt says what changed, and how to take it back." })
				]
			})
		]
	});
}
function None({ query, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold",
				children: "That doesn’t name a job yet."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: [
					"“",
					query,
					"” isn’t a known program, and it isn’t a request GetMe can match without guessing. Guessing is how the wrong installer runs."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2",
				children: SUGGESTIONS.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onPick(item),
					className: "min-h-11 rounded-2xl border border-line px-4 text-left text-sm hover:border-primary/50",
					children: item
				}, item))
			})
		]
	});
}
function Pick({ journey }) {
	const pickSoftware = useGetme((s) => s.pickSoftware);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-primary",
			children: journey.via
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 text-2xl font-semibold",
			children: "Which one?"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-2",
			children: journey.candidateIds.map((id) => {
				const software = softwareById(id);
				if (!software) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => pickSoftware(id),
					className: "rounded-2xl border border-line bg-bg px-4 py-3 text-left hover:border-primary/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium",
						children: software.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-muted",
						children: software.blurb
					})]
				}, id);
			})
		})]
	});
}
function Present({ journey }) {
	const installs = useGetme((s) => s.installs);
	const openHelp = useGetme((s) => s.openHelp);
	const openGone = useGetme((s) => s.openGone);
	const setView = useGetme((s) => s.setView);
	const anotherCopy = useGetme((s) => s.anotherCopy);
	const software = journey.softwareId ? softwareById(journey.softwareId) : void 0;
	const install = installs.find((i) => i.id === journey.installId);
	if (!software || !install) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: journey.via
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-1 text-2xl font-semibold",
					children: [software.name, " is already here."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: [
						"Alias ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-fg",
							children: install.alias
						}),
						". Pin ",
						install.version,
						". Installing it again would be a second copy, not a repair."
					]
				})
			] }),
			install.attention ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border border-accent/50 px-4 py-3 text-sm",
				children: install.attention
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => openHelp(install.id),
						children: "Change how it opens"
					}),
					install.updateTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => setView("updates"),
						children: "Review update"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "brass",
						onClick: () => openGone(install.id),
						children: "Remove it"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: anotherCopy,
				className: "self-start text-sm text-muted underline-offset-2 hover:underline",
				children: "Add another copy anyway"
			})
		]
	});
}
function Methods({ journey }) {
	const pickMethod = useGetme((s) => s.pickMethod);
	const showCandidates = useGetme((s) => s.showCandidates);
	const software = journey.softwareId ? softwareById(journey.softwareId) : void 0;
	if (!software) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: journey.via
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl font-semibold",
					children: software.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: software.blurb
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2",
				children: software.methods.map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => pickMethod(method.id),
					className: "rounded-2xl border border-line bg-bg px-4 py-3 text-left hover:border-primary/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: method.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipePill, { state: method.recipe })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block text-sm text-muted",
							children: method.tradeoff
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-2 block text-sm text-faint",
							children: [
								method.where,
								" Opens: ",
								method.opens,
								" ",
								method.size,
								"."
							]
						})
					]
				}, method.id))
			}),
			journey.candidateIds.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: showCandidates,
				className: "self-start text-sm text-muted underline-offset-2 hover:underline",
				children: "Those weren’t the right tools"
			}) : null
		]
	});
}
function Plan({ journey }) {
	const startRehearse = useGetme((s) => s.startRehearse);
	const showMethods = useGetme((s) => s.showMethods);
	const software = journey.softwareId ? softwareById(journey.softwareId) : void 0;
	const method = software && journey.methodId ? methodOf(software, journey.methodId) : void 0;
	if (!software || !method) return null;
	const plan = planDocument(software, method);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold",
				children: method.recipe === "missing" ? "A plan, not permission." : "This is the recipe."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: method.recipe === "missing" ? "Nothing verified matches this method on Windows 11 24H2. What follows was schema-checked. It still does not run until you rehearse it, then approve the real install." : method.recipe === "lagging" ? "Verified for an older pin. You can still pick the newer portable recipe instead." : "Rehearsal happens in a model of Windows. Your profile changes only after you approve the real run."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: method.actions.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-bg px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-faint",
						children: action.op
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block",
						children: action.summary
					})]
				}, action.summary))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["Check when it finishes: ", method.verify]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-2xl bg-bg px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "text-sm text-muted",
					children: "Show the plan the executor checks"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 max-w-full overflow-x-auto font-mono text-xs text-faint",
					children: JSON.stringify(plan, null, 2)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: startRehearse,
					children: "Rehearse it"
				}), software.methods.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: showMethods,
					children: "Back to choices"
				}) : null]
			})
		]
	});
}
function Rehearse({ journey }) {
	const startInstall = useGetme((s) => s.startInstall);
	const ready = journey.scriptIndex >= journey.script.length && journey.script.length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold",
				children: "Rehearsal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Modeled Windows. Nothing on the sample profile moves until you say so. A finished rehearsal is a prediction — the real install is observed again."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: startInstall,
				disabled: !ready,
				children: ready ? "Install on this profile" : "Rehearsing…"
			})
		]
	});
}
function Installing({ journey }) {
	const commitInstall = useGetme((s) => s.commitInstall);
	const ready = journey.scriptIndex >= journey.script.length && journey.script.length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold",
				children: "On the profile"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "One approval covers the plan. You won’t be asked again for each file."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: commitInstall,
				disabled: !ready,
				children: ready ? "Choose how you’ll open it" : "Installing…"
			})
		]
	});
}
function AccessToggles({ selected, onToggle, hotkey, onHotkey }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-2",
		children: ACCESS.map((item) => {
			const on = selected.includes(item.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-bg px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: on,
						onChange: () => onToggle(item.id),
						className: "size-4 accent-primary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm text-muted",
						children: item.detail
					})] })]
				}), item.id === "hotkey" && on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pr-2 pb-2 pl-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: hotkey,
						onChange: (event) => onHotkey(event.target.value),
						placeholder: "Ctrl+Alt+Space",
						className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-surface px-3 text-base"
					})
				}) : null]
			}, item.id);
		})
	});
}
function Fit({ journey }) {
	const setAliasDraft = useGetme((s) => s.setAliasDraft);
	const toggleAccess = useGetme((s) => s.toggleAccess);
	const setHotkeyDraft = useGetme((s) => s.setHotkeyDraft);
	const saveFit = useGetme((s) => s.saveFit);
	const software = journey.softwareId ? softwareById(journey.softwareId) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "text-2xl font-semibold",
				children: [
					"Make ",
					software?.name,
					" yours."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "This is part of the receipt, not a separate favor. You can change it later."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1.5 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "What you’ll call it"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: journey.aliasDraft,
					onChange: (event) => setAliasDraft(event.target.value),
					className: "min-h-11 rounded-2xl border border-line bg-bg px-3 text-base font-mono"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessToggles, {
				selected: journey.accessDraft,
				onToggle: toggleAccess,
				hotkey: journey.hotkeyDraft,
				onHotkey: setHotkeyDraft
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: saveFit,
				children: "Save and show the receipt"
			})
		]
	});
}
function AccessEditor(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessToggles, { ...props });
}
function Receipt({ journey }) {
	const installs = useGetme((s) => s.installs);
	const events = useGetme((s) => s.events);
	const openHelp = useGetme((s) => s.openHelp);
	const openGone = useGetme((s) => s.openGone);
	const setView = useGetme((s) => s.setView);
	const share = useGetme((s) => s.acknowledgeShare);
	const software = journey.softwareId ? softwareById(journey.softwareId) : void 0;
	const method = software && journey.methodId ? methodOf(software, journey.methodId) : void 0;
	const install = installs.find((i) => i.id === journey.installId);
	if (!software || !install || !method) return null;
	const mine = events.filter((event) => event.installId === install.id);
	const packet = {
		software: software.name,
		method: method.id,
		recipe: method.recipeId,
		os: "Windows 11 24H2",
		arch: "x64",
		result: "verified",
		paths: "[redacted]"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "Installed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl font-semibold",
					children: software.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: [
						"Call it ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-fg",
							children: install.alias
						}),
						". Pin ",
						install.version,
						". ",
						mine.length,
						" recorded effects."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-col gap-1 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Opens: ",
						install.access.map((id) => ACCESS.find((a) => a.id === id)?.label ?? id).join(", ") || "no launcher",
						"."
					] }),
					install.hotkey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Hotkey ",
						install.hotkey,
						"."
					] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Remove with getgone ",
						install.alias,
						". Change access with gethelp ",
						install.alias,
						"."
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => openHelp(install.id),
						children: "Change how it opens"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => setView("record"),
						children: "Open the record"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "brass",
						onClick: () => openGone(install.id),
						children: "Remove it"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-bg p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Share installation metadata?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Optional, and separate from doing the install. Declining does not weaken removal. The packet below is redacted."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-3 overflow-x-auto font-mono text-xs text-faint",
						children: JSON.stringify(packet, null, 2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						variant: "quiet",
						onClick: share,
						disabled: journey.share,
						children: journey.share ? "Marked. Nothing was uploaded." : "Mark this packet for sharing"
					})
				]
			})
		]
	});
}
function Library$1() {
	const installs = useGetme((s) => s.installs);
	const events = useGetme((s) => s.events);
	const openHelp = useGetme((s) => s.openHelp);
	const openGone = useGetme((s) => s.openGone);
	const setView = useGetme((s) => s.setView);
	const submit = useGetme((s) => s.submit);
	const live = installs.filter((i) => i.status === "installed");
	const removed = installs.filter((i) => i.status === "removed");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "Yours"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: "Software this profile asked GetMe to be responsible for. An alias picks an install. It is not a list of files to delete."
			})] }),
			live.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Nothing is managed right now."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => setView("ask"),
				children: "Ask for something"
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: live.map((install) => {
					const software = softwareById(install.softwareId);
					const method = software && methodOf(software, install.methodId);
					const count = events.filter((event) => event.installId === install.id).length;
					if (!software) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: install.attention ? "border-accent/60" : void 0,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-semibold",
									children: software.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: software.blurb
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
									tone: "quiet",
									children: install.alias
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 grid gap-3 text-sm sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "How it opens"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "mt-1",
										children: [install.access.map((id) => ACCESS.find((a) => a.id === id)?.label ?? id).join(", "), install.hotkey ? ` · ${install.hotkey}` : ""]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "Since"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 tabular-nums",
										children: formatWhen(install.installedAt)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "Method"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1",
										children: method?.label
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "Record"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "mt-1 tabular-nums",
										children: [
											"Pin ",
											install.version,
											install.updateTo ? ` · ${install.updateTo} waiting` : "",
											" · ",
											count,
											" events"
										]
									})] })
								]
							}),
							install.attention ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-accent",
								children: install.attention
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "quiet",
										onClick: () => openHelp(install.id),
										children: "How I use it"
									}),
									install.updateTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "quiet",
										onClick: () => setView("updates"),
										children: "Update"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "brass",
										onClick: () => openGone(install.id),
										children: "Remove"
									})
								]
							})
						]
					}) }, install.id);
				})
			}),
			removed.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-muted",
					children: "Removed, still in the record"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: removed.map((install) => {
						const software = softwareById(install.softwareId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => submit(software?.name ?? install.alias),
							className: "flex min-h-11 w-full items-center justify-between rounded-2xl border border-line px-4 text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: software?.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-faint",
								children: "Ask again"
							})]
						}) }, install.id);
					})
				})]
			}) : null
		]
	});
}
function downloadJson(filename, data) {
	const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	anchor.click();
	URL.revokeObjectURL(url);
}
var FACTS = [
	{
		label: "System",
		value: `${MACHINE.os} · build ${MACHINE.build}`
	},
	{
		label: "Architecture",
		value: MACHINE.arch
	},
	{
		label: "CPU",
		value: MACHINE.cpu
	},
	{
		label: "Memory",
		value: MACHINE.ram
	},
	{
		label: "Disk",
		value: MACHINE.diskFree
	},
	{
		label: "WSL",
		value: MACHINE.wsl
	},
	{
		label: "Scoop",
		value: MACHINE.scoop
	},
	{
		label: "GPU",
		value: MACHINE.gpu,
		note: MACHINE.gpuNote
	},
	{
		label: "Execution policy",
		value: MACHINE.executionPolicy
	}
];
function Machine() {
	const policy = useGetme((s) => s.policy);
	const setPolicy = useGetme((s) => s.setPolicy);
	const events = useGetme((s) => s.events);
	const installs = useGetme((s) => s.installs);
	const chainTip = useGetme((s) => s.chainTip);
	const depart = useGetme((s) => s.depart);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "This PC"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: "A sample Windows profile the front end can rehearse against. The native harness is not attached, so nothing here changes a real computer."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "What was collected"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Enough to choose an install. Not a personal inventory."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-4 grid gap-4 sm:grid-cols-2",
					children: FACTS.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-faint",
							children: fact.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1",
							children: fact.value
						}),
						fact.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-sm text-muted",
							children: fact.note
						}) : null
					] }, fact.label))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "When something turns itself back on"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-col gap-2",
					children: PERSISTENCE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 gap-3 rounded-2xl border border-line bg-bg px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "radio",
							name: "persistence",
							checked: policy.persistence === item.id,
							onChange: () => setPolicy({ persistence: item.id }),
							className: "mt-1 size-4 accent-primary"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: item.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: item.detail
						})] })]
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Beacon’s task already came back. Changing this now does not rewrite that. It applies the next time."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "GetMe on this profile"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 flex flex-col gap-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "This front end." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The journal, including receipts for Krita, Blender, and Beacon." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Observation of files, registry, services, and scheduled tasks. Visible here. Turned off if GetMe leaves." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Sharing metadata is off. Hosted reasoning, if a later harness uses it, is a separate disclosure. Declining a share never blocks removal."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: policy.shareMetadata,
						onChange: (event) => setPolicy({ shareMetadata: event.target.checked }),
						className: "size-4 accent-primary"
					}), "Remember that I am willing to be asked about sharing"]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "border-accent/40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Remove GetMe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "GetMe has to meet its own rule. Export the journal first if you want the receipts after it is gone. This rehearsal can put GetMe back."
					}),
					open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "flex flex-col gap-1 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Managed installs stay described only in the export you keep." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Observation stops." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Nothing already sent anywhere is unsent. Nothing was sent." })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								onClick: () => downloadJson("getme-record.json", {
									chainTip,
									machine: MACHINE,
									installs,
									events
								}),
								children: "Export the journal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "brass",
								onClick: depart,
								children: "Remove GetMe from this rehearsal"
							})]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						variant: "quiet",
						onClick: () => setOpen(true),
						children: "Show what removal would do"
					})
				]
			})
		]
	});
}
function Sheet({ open, title, description, locked, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (!next && !locked) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-bg/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed inset-x-3 top-4 bottom-4 z-50 mx-auto max-w-xl overflow-y-auto rounded-3xl border border-line bg-bg-raised p-5 shadow-lift focus:outline-none sm:inset-x-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "text-xl font-semibold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-2 text-sm text-muted",
					children: description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children
				})
			]
		})] })
	});
}
function Overlays() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpSheet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoneSheet, {})] });
}
function HelpSheet() {
	const help = useGetme((s) => s.help);
	const helpError = useGetme((s) => s.helpError);
	const installs = useGetme((s) => s.installs);
	const closeHelp = useGetme((s) => s.closeHelp);
	const setHelpAlias = useGetme((s) => s.setHelpAlias);
	const toggleHelpAccess = useGetme((s) => s.toggleHelpAccess);
	const setHelpHotkey = useGetme((s) => s.setHelpHotkey);
	const saveHelp = useGetme((s) => s.saveHelp);
	const install = installs.find((i) => i.id === help?.installId);
	const software = install ? softwareById(install.softwareId) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: Boolean(help),
		title: software ? `How you use ${software.name}` : "How you use it",
		description: "A friendly name selects this install. It is not, by itself, permission to delete anything.",
		onClose: closeHelp,
		children: help ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Alias",
					hint: "What you’ll type after gethelp or getgone.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: help.alias,
						onChange: (event) => setHelpAlias(event.target.value),
						className: inputClass
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessEditor, {
					selected: help.access,
					onToggle: toggleHelpAccess,
					hotkey: help.hotkey,
					onHotkey: setHelpHotkey
				}),
				helpError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-accent",
					children: helpError
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: saveHelp,
						children: "Save"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: closeHelp,
						children: "Cancel"
					})]
				})
			]
		}) : null
	});
}
function GoneSheet() {
	const gone = useGetme((s) => s.gone);
	const installs = useGetme((s) => s.installs);
	const closeGone = useGetme((s) => s.closeGone);
	const setAccent = useGetme((s) => s.setAccent);
	const setKeepDocs = useGetme((s) => s.setKeepDocs);
	const beginRemoval = useGetme((s) => s.beginRemoval);
	const advanceGone = useGetme((s) => s.advanceGone);
	const skipGone = useGetme((s) => s.skipGone);
	const completeGone = useGetme((s) => s.completeGone);
	const install = installs.find((i) => i.id === gone?.installId);
	const software = install ? softwareById(install.softwareId) : void 0;
	const playing = gone?.phase === "working" && gone.scriptIndex < gone.script.length;
	usePlayScript(Boolean(playing), gone?.scriptIndex ?? 0, gone?.script.length ?? 0, advanceGone, skipGone);
	const phase = gone?.phase;
	const scriptIndex = gone?.scriptIndex ?? 0;
	const scriptLength = gone?.script.length ?? 0;
	(0, import_react.useEffect)(() => {
		if (phase === "working" && scriptLength > 0 && scriptIndex >= scriptLength) completeGone();
	}, [
		phase,
		scriptIndex,
		scriptLength,
		completeGone
	]);
	const preview = software && gone ? removalScript(software, gone.accent, gone.keepDocs) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: Boolean(gone && install),
		title: software ? `Remove ${software.name}` : "Remove",
		description: "Undo what this install owns. Work that happened afterward stays, unless you explicitly say otherwise.",
		locked: gone?.phase === "working",
		onClose: closeGone,
		children: gone && software && install ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				gone.phase === "review" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: preview.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-2xl bg-bg px-4 py-3 text-sm",
							children: line
						}, line))
					}),
					software.id === "beacon" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium",
								children: "Accent was slate, then phosphor, then coral."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "MailStamp, which GetMe does not manage, made the latest change. Putting slate back would also erase that."
							}),
							[
								[
									"leave",
									"Leave coral",
									"Recommended. MailStamp’s later edit stays."
								],
								[
									"phosphor",
									"Back to phosphor",
									"Beacon’s value. Overwrites coral."
								],
								[
									"slate",
									"Back to slate",
									"The value from before Beacon. Overwrites both later edits."
								]
							].map(([id, label, detail]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 gap-3 rounded-2xl border border-line bg-bg px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									name: "accent",
									checked: gone.accent === id,
									onChange: () => setAccent(id),
									className: "mt-1 size-4 accent-primary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-medium",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted",
									children: detail
								})] })]
							}, id))
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: gone.keepDocs,
							onChange: (event) => setKeepDocs(event.target.checked),
							className: "size-4 accent-primary"
						}), "Keep files I created"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "brass",
							onClick: beginRemoval,
							children: ["Remove ", software.name]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: closeGone,
							children: "Cancel"
						})]
					})
				] }) : null,
				gone.phase === "working" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transcript, { lines: gone.script.slice(0, gone.scriptIndex) }), gone.scriptIndex < gone.script.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: skipGone,
						children: "Show the rest"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Writing the removal into the record…"
					})]
				}) : null,
				gone.phase === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [software.name, " is no longer managed. The record still has the install and the removal, so you can see what was restored, deleted, kept, or left unresolved."]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: closeGone,
						children: "Close"
					})]
				}) : null
			]
		}) : null
	});
}
function Record() {
	const events = useGetme((s) => s.events);
	const installs = useGetme((s) => s.installs);
	const chainTip = useGetme((s) => s.chainTip);
	const filter = useGetme((s) => s.recordFilter);
	const setFilter = useGetme((s) => s.setRecordFilter);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const aliases = /* @__PURE__ */ new Map();
	aliases.set("getme", "getme");
	for (const event of events) aliases.set(event.installId, event.alias);
	for (const install of installs) aliases.set(install.id, install.status === "removed" ? `${install.alias} · gone` : install.alias);
	const reversed = [...filter === "all" ? events : events.filter((event) => event.installId === filter || event.alias === filter)].reverse();
	const groups = [];
	for (const event of reversed) {
		const day = formatDay(event.at);
		const last = groups[groups.length - 1];
		if (!last || last.day !== day) groups.push({
			day,
			items: [event]
		});
		else last.items.push(event);
	}
	const chips = [{
		id: "all",
		label: "All"
	}];
	for (const [id, label] of aliases) if (id === "getme" || installs.some((install) => install.id === id)) chips.push({
		id,
		label
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold",
					children: "Record"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-muted",
					children: "Append-only, on this profile. Each line carries the hash of the line before it. A local chain lets you notice tampering. It does not stop an administrator from rewriting the file."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => downloadJson("getme-record.json", {
						chainTip,
						machine: MACHINE,
						installs,
						events,
						note: "Sample profile rehearsal. Hashes are a local chain, not an external anchor."
					}),
					children: "Export JSON"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: chips.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(chip.id),
					className: filter === chip.id ? "min-h-11 rounded-full bg-primary px-4 text-sm font-medium text-primary-ink" : "min-h-11 rounded-full border border-line px-4 text-sm text-muted",
					children: chip.label
				}, chip.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-sm text-faint",
				children: [
					"Tip ",
					chainTip,
					" · ",
					events.length,
					" events"
				]
			}),
			groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-muted",
					children: group.day
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: group.items.map((event) => {
						const open = openId === event.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							className: "p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOpenId(open ? null : event.id),
								className: "flex w-full flex-col gap-2 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CertaintyPill, { certainty: event.certainty }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-sm text-faint",
											children: event.alias
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-sm text-faint tabular-nums",
											children: formatWhen(event.at)
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: event.summary
								})]
							}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-col gap-2 border-t border-line pt-3 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: event.detail }),
									event.before || event.after ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-fg",
										children: [
											event.before ?? "—",
											" → ",
											event.after ?? "—"
										]
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-faint",
										children: [
											event.kind,
											" · ",
											event.hash,
											" · prev ",
											event.prev
										]
									})
								]
							}) : null]
						}) }, event.id);
					})
				})]
			}, group.day))
		]
	});
}
function Updates() {
	const installs = useGetme((s) => s.installs);
	const updateRun = useGetme((s) => s.updateRun);
	const startUpdate = useGetme((s) => s.startUpdate);
	const advanceUpdate = useGetme((s) => s.advanceUpdate);
	const skipUpdate = useGetme((s) => s.skipUpdate);
	const finishUpdate = useGetme((s) => s.finishUpdate);
	const live = installs.filter((i) => i.status === "installed");
	usePlayScript(Boolean(updateRun && updateRun.scriptIndex < updateRun.script.length), updateRun?.scriptIndex ?? 0, updateRun?.script.length ?? 0, advanceUpdate, skipUpdate);
	const ready = Boolean(updateRun && updateRun.script.length > 0 && updateRun.scriptIndex >= updateRun.script.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold",
			children: "Updates"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-muted",
			children: "Pins from the sample recipe store, not a live lookup. An update replaces owned program files. It does not reset how you open the app, and it does not pretend to be urgent."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: live.map((install) => {
				const software = softwareById(install.softwareId);
				if (!software) return null;
				const running = updateRun?.installId === install.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-semibold",
							children: software.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm text-faint",
							children: install.alias
						})]
					}),
					install.updateTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"You have pin ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: install.version
							}),
							". Pin",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: install.updateTo
							}),
							" is in the store."
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"Current for this store. Pin ",
							install.version,
							"."
						]
					}),
					running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transcript, { lines: updateRun.script.slice(0, updateRun.scriptIndex) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: finishUpdate,
								disabled: !ready,
								children: ready ? "Write it into the receipt" : "Updating…"
							}), !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: skipUpdate,
								children: "Show the rest"
							}) : null]
						})]
					}) : install.updateTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => startUpdate(install.id),
						disabled: Boolean(updateRun),
						children: "Review and install"
					}) : null
				] }) }, install.id);
			})
		})]
	});
}
var NAV = [
	{
		id: "ask",
		label: "Ask",
		icon: MessageSquare
	},
	{
		id: "library",
		label: "Yours",
		icon: Library
	},
	{
		id: "updates",
		label: "Updates",
		icon: RefreshCw
	},
	{
		id: "record",
		label: "Record",
		icon: ScrollText
	}
];
function GetMeApp() {
	const removed = useGetme((s) => s.selfRemoved);
	(0, import_react.useEffect)(() => {
		useGetme.persist.rehydrate();
	}, []);
	if (removed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Departure, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
function Departure() {
	const reset = useGetme((s) => s.reset);
	const count = useGetme((s) => s.events.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen max-w-lg flex-col justify-center gap-5 px-6 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/mark.png",
				alt: "",
				width: 72,
				height: 72,
				className: "mark-glow size-16 rounded-3xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "Removed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-semibold",
					children: "GetMe has left this rehearsal."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-muted",
					children: [
						"Observation is off. The journal had ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-fg",
							children: count
						}),
						" events. If you exported it, that file is the copy you kept. Nothing was uploaded, so there is nothing remote to undo."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: reset,
				className: "self-start",
				children: "Put GetMe back"
			})
		]
	});
}
function Shell() {
	const view = useGetme((s) => s.view);
	const setView = useGetme((s) => s.setView);
	const notice = useGetme((s) => s.notice);
	const setNotice = useGetme((s) => s.setNotice);
	const installs = useGetme((s) => s.installs);
	const drift = installs.filter((i) => i.status === "installed" && i.attention).length;
	const updates = installs.filter((i) => i.status === "installed" && i.updateTo).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen lg:flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-line bg-bg-raised px-4 py-5 lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex flex-col gap-1",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							item,
							active: view === item.id,
							count: item.id === "library" ? drift : item.id === "updates" ? updates : 0,
							onClick: () => setView(item.id)
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setView("machine"),
						className: cn("mt-auto flex min-h-11 items-center gap-3 rounded-2xl px-3 text-left text-sm", view === "machine" ? "bg-primary text-primary-ink" : "text-muted hover:bg-surface hover:text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, {
							className: "size-4 shrink-0",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: "This PC"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: view === "machine" ? "block text-primary-ink/80" : "block text-faint",
							children: "Sample profile"
						})] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setView("machine"),
						className: cn("inline-flex min-h-11 items-center gap-2 rounded-full border border-line px-3 text-sm", view === "machine" ? "bg-primary text-primary-ink" : "text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, {
							className: "size-4",
							"aria-hidden": "true"
						}), "This PC"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto flex w-full max-w-5xl flex-1 flex-col px-4 pt-4 pb-24 lg:pt-6 lg:pb-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandBar, { prominent: view === "ask" }),
						notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-start justify-between gap-3 rounded-2xl border border-line bg-surface px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: notice }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setNotice(null),
								className: "min-h-11 shrink-0 text-muted",
								children: "Dismiss"
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rise mt-4",
							children: [
								view === "ask" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ask, {}) : null,
								view === "library" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library$1, {}) : null,
								view === "updates" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Updates, {}) : null,
								view === "record" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Record, {}) : null,
								view === "machine" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Machine, {}) : null
							]
						}, view)
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 flex border-t border-line bg-bg lg:hidden",
				children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setView(item.id),
					className: cn("flex min-h-14 flex-1 flex-col items-center justify-center gap-1 text-sm", view === item.id ? "text-primary" : "text-faint"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
							className: "size-4",
							"aria-hidden": "true"
						}),
						item.label,
						item.id === "library" && drift > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "sr-only",
							children: [drift, " need attention"]
						}) : null,
						item.id === "updates" && updates > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "sr-only",
							children: [updates, " updates"]
						}) : null
					]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlays, {})
		]
	});
}
function Brand({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/mark.png",
			alt: "",
			width: 44,
			height: 44,
			className: "mark-glow size-11 rounded-2xl"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-lg font-semibold leading-none",
			children: ["Get", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-primary",
				children: "Me"
			})]
		}), compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-faint",
			children: "because we got you"
		})] })]
	});
}
function NavButton({ item, active, count, onClick }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex min-h-11 items-center gap-3 rounded-2xl px-3 text-sm", active ? "bg-primary font-medium text-primary-ink" : "text-muted hover:bg-surface hover:text-fg"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-4 shrink-0",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 text-left",
				children: item.label
			}),
			count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("tabular-nums", active ? "text-primary-ink" : "text-accent"),
				children: count
			}) : null
		]
	});
}
function CommandBar({ prominent }) {
	const submit = useGetme((s) => s.submit);
	const [value, setValue] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => {
			event.preventDefault();
			const next = value.trim();
			if (!next) return;
			submit(next);
			setValue("");
		},
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: "getme-command",
			className: prominent ? "text-sm font-medium text-muted" : "sr-only",
			children: "Ask, or type getme, getgone, gethelp, getupdates"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "getme-command",
				value,
				onChange: (event) => setValue(event.target.value),
				placeholder: prominent ? "comfyui, or something that takes dictation" : "getgone beacon",
				autoComplete: "off",
				className: "min-h-12 w-full flex-1 rounded-full border border-line bg-bg-raised px-5 text-base text-fg outline-none placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "Go"
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GetMeApp, {});
}
//#endregion
export { Home as component };
